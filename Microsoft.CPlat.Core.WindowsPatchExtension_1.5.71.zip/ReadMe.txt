0. Either build the code base and copy the bin to the new test VM or get the the latest output files from share folder
   \\cdmstore\Data\jeabdu\ExtensionOutputFiles
1. Rename the HandlerEnvironmentTest.json to HandlerEnvironment.json
2. Open the handler environment json and update your desire path for:
    1. logFolder
    2. configFolder
    3. statusFolder
    4. telemetryLogFolder
3. copy SampleSettingFile.settings to your config folder location and rename it to <sequenceNumber>.settings
4. Every time you rerun the the extension, update the setting name with the new sequence number. If you rerun with the same sequence number, it will be nooperation
5. To specify what operation the extension you want to operate, open the setting file and change the value of "operation". possible values are Assessment, Installation or NoOperation.
6. Once step 1-5 is completed, open command window with Administrator. Cd to the location where the file "WindowsVmUpdateExtension.exe" is reside. then run the executable the enable command.
     
           WindowsVmUpdateExtension.exe enable

7. to see the log, go to the log folder location you specified in the handlerEnvironment.json
   to see the status, go to the status folder location you specified in the handlerEnvironment.json